Rock Bottom Brewery — website export
=====================================

This is a single self-contained page: index.html.

To view it:
- Double-click index.html to open it in any browser, or
- Drag the file into a browser window.

Notes:
- All CSS and JavaScript are inlined in index.html — there are no other
  files to keep track of.
- Fonts (Fraunces, Work Sans, Caveat) load from Google Fonts over the
  internet, so an active connection is needed for the type to render
  as designed (the page still works fine offline, just with fallback
  system fonts).
- The hero imagery is built entirely with CSS gradients rather than
  photos, so there are no image assets to replace unless you want to
  swap in real photography — just add <img> or background-image rules
  inside the .slide-bg elements.
- To host this live, upload index.html to any static host (Netlify,
  Vercel, GitHub Pages, S3, etc.) — no build step required.
